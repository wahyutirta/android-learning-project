package com.example.mygithubproject.services.dataclass

import com.example.mygithubproject.services.data.UsersData

data class UserResponses(
    val items: ArrayList<UsersData>
)