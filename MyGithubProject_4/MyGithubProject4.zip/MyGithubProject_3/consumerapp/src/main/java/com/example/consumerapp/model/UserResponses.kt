package com.example.consumerapp.model

import com.example.consumerapp.model.UsersData


data class UserResponses(
    val items: ArrayList<UsersData>
)