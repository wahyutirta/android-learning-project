package com.example.mygithubproject.services.dataclass

data class ReminderNotify (
    var checkReminder: Boolean = false
)