package com.example.consumerapp

import com.example.consumerapp.model.UsersData


data class UserResponses(
    val items: ArrayList<UsersData>
)