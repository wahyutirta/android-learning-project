package com.example.mygithubuserfavorite.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}