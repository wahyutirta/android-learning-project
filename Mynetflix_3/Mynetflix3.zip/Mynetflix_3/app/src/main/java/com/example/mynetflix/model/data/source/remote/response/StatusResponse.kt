package com.example.mynetflix.model.data.source.remote.response

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}