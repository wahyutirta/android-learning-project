package com.example.mynetflix.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}